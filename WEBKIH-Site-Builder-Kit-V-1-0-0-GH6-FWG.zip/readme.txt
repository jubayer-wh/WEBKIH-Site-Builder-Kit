=== WEBKIH Site Builder Kit ===
Contributors: jubayerh1, webkih
Tags: website builder, shortcodes, agency, hero, slider, team, packages
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 1.0.0
License: GPLv2 or later

A modular website builder toolkit by WEBKIH. Add hero, slider, team, packages, contact, loader via shortcodes and much more...

== Installation ==
1. Upload plugin folder to /wp-content/plugins/
2. Activate in Plugins
3. Go to WEBKIH Kit from Dashboard

== Shortcodes ==
[wbk_hero1]
[wbk_slider1]
[wbk_team1]
[wbk_package1]
[wbk_contact1]
[wbk_loader1]

== Changelog ==
= 1.0.0 =
Initial release
